let snake = new Snake(4,5)
let map = new Map()
let apple1 = new Apple()
let apple2 = new Apple()
let apple3 = new Apple()
let bomb1 = new Bomb()
let bomb2 = new Bomb()
let heart = new Heart()
let mouse1 = new Mouse()
let mouse2 = new Mouse()
let coin = new Coin()

map.children.push(apple1)
map.children.push(apple2)
map.children.push(apple3)
map.children.push(snake)
map.children.push(bomb1)
map.children.push(bomb2)
map.children.push(heart)
map.children.push(mouse1)
map.children.push(mouse2)
map.children.push(coin)
map.render(container)



setInterval( () => {
    snake.move()
    map.render(container)
}, 1000)


const userAction = (e) => {
console.log(e)
switch(e.code){
    case "ArrowUp": snake.children[0].dir = "up"; break;
    case "ArrowRight": snake.children[0].dir = "right"; break;
    case "ArrowDown": snake.children[0].dir = "down"; break;
    case "ArrowLeft": snake.children[0].dir = "left"; break;
}
}