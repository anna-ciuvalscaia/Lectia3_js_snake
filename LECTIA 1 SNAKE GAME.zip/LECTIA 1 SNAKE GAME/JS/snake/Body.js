class Body {
    constructor(x=0, y=0, dir){
        this.x = x
        this.y = y
        this.dir = dir
        /*this.x = [x, x-1, x+1, x]
        this.y = [y+1, y, y, y-1]
        this.i = i
        ///          up  rg  lf  dn
        this.dirX = [128, 64, 64, 128]
        this.dirY = [64, 0, 0, 64]*/
      
         }
    render(){
return `
<div 
style="
width: 64px;
height: 64px;
background: url(images/snake-graphics.png);
background-position: -128px -64px;
position: absolute;
 top: ${this.y*64}px;
 left: ${this.x*64}px;
"
></div>
`
    }
}

