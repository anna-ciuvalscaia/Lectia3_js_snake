// [Snake] > parent > [Head]

class Snake {
    // when creating a new snake -> attach a head to it
    constructor(x, y, dir="right"){
    
        //snake segments/elements
       this.children = []
       this.children.push(new Head(x,y, "right"))
       this.children.push(new Body(x,y + 1, "up"))
       //this.children.push(new Body(x,y + 2, "up"))
       this.children.push(new Tail(x,y + 2, dir))
     
      
    }

    move() {

       this.children.reverse()
 
// [ Tail, Body, Head ]
        this.children.forEach( (s, i) => {
            if(i == this.children.length - 1) {
            if(s.dir == "up") {if (s.y == 0){s.dir = "right"} else {s.y--}}
            if(s.dir == "right") {if (s.x == 9){ s.dir = "down"} else {s.x++}}
            if(s.dir == "down") {if (s.y ==9){ s.dir = "left"} else{s.y++}}
            if(s.dir == "left") {if (s.x ==0){ s.dir = "up"} else{s.x--}} 
            } else {
                s.x = this.children[i+1].x
                s.y = this.children[i+1].y
            } 
            
        })

        this.children.reverse() 
        
    }
    
    // when rendering the SNAKE - also render
    render(){
        let html = ``
        for(let i=0; i<this.children.length; i++){
            html += this.children[i].render()
        }
       return html
      
    }
   
}

