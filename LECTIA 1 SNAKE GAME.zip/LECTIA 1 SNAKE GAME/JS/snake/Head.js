
class Head {
   
    constructor(x=0, y=0, dir){
       this.x = x
       this.y = y 
       this.dir = dir
     /*  this.i = i
       ///          up  rg  lf  dn
       this.dirX =[192, 256, 192, 256 ] 
       this.dirY = [0, 0, 64, 64] */  
        }

    render(){
        return`
<div id="head" 
style="
width: 64px;
height: 64px;
background: url(images/snake-graphics.png);
background-position: -192px -0px;
position: absolute;
 top: ${this.y*64}px;
 left: ${this.x*64}px;
"
></div>`
    }
}



